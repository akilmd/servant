
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE TypeOperators #-}

module Lib
    ( startApp
    ) where

import Servant
import Network.Wai.Handler.Warp (run)

type API = "hello" :> Get '[PlainText] String

startApp :: IO()
startApp = run 8080 app

app :: Application
app = serve api server

api :: Proxy API
api = Proxy

server :: Server API
server = return "Hello, Haskell Servant!"