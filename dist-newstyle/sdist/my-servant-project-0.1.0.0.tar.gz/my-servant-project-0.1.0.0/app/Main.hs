module Main where

import Lib (startApp)

main :: IO ()
main = startApp
